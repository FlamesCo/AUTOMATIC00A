document.getElementById("main").childNodes[0].style = "max-width: 800px; margin-left: auto; margin-right: auto";
document.getElementById("extensions").style.setProperty("max-width", "800px");
document.getElementById("extensions").style.setProperty("margin-left", "auto");
document.getElementById("extensions").style.setProperty("margin-right", "auto");
