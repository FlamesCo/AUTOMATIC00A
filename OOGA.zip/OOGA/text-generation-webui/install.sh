#!/bin/bash

# Install Homebrew (if not already installed)
command -v brew >/dev/null 2>&1 || /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Python and dependencies via Homebrew 
brew install python@3

# Setup environment variables for Rosetta emulation (optional if running in native ARM mode)
export PATH="/usr/local/opt/python@3/libexec/bin:$PATH"
export LDFLAGS="-L/usr/local/opt/python@3/lib"
export CPPFLAGS="-I/usr/local/opt/python@3/include"

# Clone the GitHub repository
git clone https://github.com/oobabooga/text-generation-webui.git

# Navigate to the cloned repository folder
cd text-generation-webui

# Create a virtual environment (optional but recommended)
python -m venv venv       # Create virtual environment named "venv"
source venv/bin/activate # Activate virtual environment 

# Install required packages from requirements.txt
pip install --upgrade pip wheel setuptools     # Upgrade essential packages first  
pip install --no-cache-dir numpy               # Workaround for potential installation issues with NumPy    
pip install --no-cache-dir torch torchvision torchaudio cpuinfo psutil        # Required PyTorch dependencies       
pip install --no-cache-dir flask gradio gdown pyyaml requests brownie markdown  # Other required packages

# Run the web UI
python server.py

